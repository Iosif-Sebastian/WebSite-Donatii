<?php
session_start();
include 'db.php';
$userRole = $_SESSION['userRole'] ?? '';

// Preluăm toate donațiile din DB
$stmt = $pdo->query("SELECT * FROM donatii ORDER BY id DESC");
$donatii = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search For a Cause | Home</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="grid-container">

    <header class="header">
        <div class="logo">SearchForACause</div>
        <nav class="nav-links">
            <a href="About.html">Despre</a>
            <a href="Organisations.php">Organizații</a>
            <a href="Events.php">Evenimente</a>
            <a href="Contact.php">Contact</a>
            <?php if(!$userRole): ?>
                <button id="loginBtn">Autentifică-te</button>
            <?php else: ?>
                <span>Bine ai venit, <?php echo htmlspecialchars($userRole); ?></span>
                <button onclick="window.location.href='logout.php'">Ieși</button>
                <button id="openCreateBtn">Creează Donație</button>
            <?php endif; ?>
        </nav>
    </header>

    <main class="main-content">
        <h1 class="welcome-title">Bun venit pe site-ul nostru!</h1>
        <p class="welcome-text">Puteți crea câte donații doriți și le veți vedea imediat mai jos.</p>

        <h2 class="page-title">Donațiile noastre</h2>
        <div class="card-container" id="lista-donatii">
            <?php foreach($donatii as $donatie): ?>
            <div class="card" data-id="<?php echo $donatie['id']; ?>">
                <img src="<?php echo htmlspecialchars($donatie['image_path']); ?>" alt="<?php echo htmlspecialchars($donatie['titlu']); ?>">
                <div class="titlu"><p><?php echo htmlspecialchars($donatie['titlu']); ?></p></div>
                <p><?php echo htmlspecialchars($donatie['descriere']); ?></p>
                <p>Suma: <span class="suma"><?php echo number_format($donatie['suma'],2); ?></span> RON</p>
                <button class="donateBtn">Donează</button>
                <?php if($userRole === 'admin'): ?>
                    <button class="editBtn">Editează</button>
                    <button class="deleteBtn">Șterge</button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer class="footer">
        <p>© 2026 Search For a Cause — Toate drepturile rezervate</p>
    </footer>
</div>

<div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeLogin">&times;</span>
        <p>Conectează-te</p>
        <div id="loginChoice">
            <button id="userLoginBtn">User</button>
            <button id="adminLoginBtn">Admin</button>
            <button id="createUserBtn">Creează cont</button>
        </div>
        <form id="loginForm" method="POST" action="login.php" style="display:none;">
            <input type="hidden" name="role" id="loginRole" value="">
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Parola:</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>
        <p id="createUserLink" style="display:none;">
            Nu ai cont? <a href="CreareCont.html">Creează unul</a>
        </p>
    </div>
</div>

<div id="createModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeCreate">&times;</span>
        <p id="modalTitle">Creează Donație</p>
        <form id="createDonationForm">
            <input type="hidden" name="donation_id" id="donation_id" value="">
            <input type="text" name="titlu" id="title" placeholder="Titlu" required>
            <textarea name="descriere" id="description" placeholder="Descriere" required></textarea>
            <input type="text" name="image_path" id="image" placeholder="URL imagine" required>
            <input type="number" step="0.01" name="suma" id="amount" placeholder="Sumă inițială" required>
            <button type="submit" id="donationBtn">Trimite donație</button>
        </form>
    </div>
</div>

<a href="#top" class="back-to-top">⬆ Mergi sus</a>

<script>
window.userRole = "<?php echo $userRole; ?>";
</script>
<script src="script.js"></script>
</body>
</html>
