const backToTopBtn = document.querySelector('.back-to-top');

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopBtn.style.display = 'block';
    } else {
        backToTopBtn.style.display = 'none';
    }
});

backToTopBtn.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

const form = document.querySelector('.contact-form');
form.addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmapassword').value;

    if(password !== confirmPassword) {
        e.preventDefault();
        alert('Parola și confirmarea parolei nu coincid!');
        return false;
    }

    const termsAccepted = document.getElementById('termeni').checked;
    if(!termsAccepted) {
        e.preventDefault();
        alert('Trebuie să accepți termenii și condițiile!');
        return false;
    }
});
