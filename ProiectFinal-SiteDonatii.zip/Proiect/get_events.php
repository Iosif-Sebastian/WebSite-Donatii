<?php
header('Content-Type: application/json');

$host = 'mysql';
$port = 3306;
$db = 'studenti';
$user = 'user';
$pass = 'password';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Eroare conectare DB: " . $e->getMessage()]);
    exit;
}

try {
    $stmt = $pdo->query("SELECT titlu, descriere, locatie, data_eveniment, image_path FROM events ORDER BY data_eveniment ASC");
    $events = $stmt->fetchAll();
    echo json_encode($events);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Eroare query: " . $e->getMessage()]);
}
