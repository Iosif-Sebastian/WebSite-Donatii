document.addEventListener('DOMContentLoaded', () => {
    const userRole = window.userRole || "";
    const loginModal = document.getElementById('loginModal');
    const createModal = document.getElementById('createModal');
    const loginForm = document.getElementById('loginForm');
    const loginChoice = document.getElementById('loginChoice');
    const createUserLink = document.getElementById('createUserLink');
    const loginRoleInput = document.getElementById('loginRole');
    const listaDonatii = document.getElementById('lista-donatii');

    const loginBtn = document.getElementById('loginBtn');
    const openCreateBtn = document.getElementById('openCreateBtn');
    const closeLoginBtn = document.getElementById('closeLogin');
    const closeCreateBtn = document.getElementById('closeCreate');

    if(loginBtn){
        loginBtn.addEventListener('click', () => {
            loginModal.style.display = 'flex';
            loginChoice.style.display = 'block';
            loginForm.style.display = 'none';
            createUserLink.style.display = 'none';
        });
    }
    if(closeLoginBtn) closeLoginBtn.addEventListener('click', () => loginModal.style.display = 'none');
    if(closeCreateBtn) closeCreateBtn.addEventListener('click', () => createModal.style.display = 'none');


    const userLoginBtn = document.getElementById('userLoginBtn');
    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const createUserBtn = document.getElementById('createUserBtn');

    if(userLoginBtn) userLoginBtn.addEventListener('click', () => switchLogin('user'));
    if(adminLoginBtn) adminLoginBtn.addEventListener('click', () => switchLogin('admin'));
    if(createUserBtn) createUserBtn.addEventListener('click', () => switchLogin('create'));

    function switchLogin(role){
        loginRoleInput.value = role;
        loginChoice.style.display = 'none';
        if(role === 'create'){
            loginForm.style.display = 'none';
            createUserLink.style.display = 'block';
        } else {
            loginForm.style.display = 'block';
            createUserLink.style.display = 'none';
        }
    }

  
    if(openCreateBtn){
        openCreateBtn.addEventListener('click', () => {
            if(!userRole){
                alert("Trebuie să te autentifici!");
                return;
            }
            createModal.style.display = 'flex';
            document.getElementById('createDonationForm').reset();
            document.getElementById('donation_id').value = '';
            document.getElementById('modalTitle').textContent = "Creează Donație";
        });
    }

    function attachCardEvents(card) {
        const sumaSpan = card.querySelector('.suma');

        card.querySelector('.donateBtn').addEventListener('click', () => {
            const sumaInput = prompt("Introdu suma pe care vrei să o donezi:", "0");
            const sumaNoua = parseFloat(sumaInput);
            if(!isNaN(sumaNoua) && sumaNoua > 0){
                const newSum = parseFloat(sumaSpan.textContent) + sumaNoua;
                sumaSpan.textContent = newSum.toFixed(2);

              
                fetch('donation.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        donation_id: card.dataset.id,
                        suma: newSum
                    })
                });
            }
        });

        if(userRole === 'admin'){
            const editBtn = card.querySelector('.editBtn');
            const deleteBtn = card.querySelector('.deleteBtn');

            editBtn.addEventListener('click', () => {
                const titlu = card.querySelector('.titlu p').textContent;
                const descriere = card.querySelector('p:nth-of-type(1)').textContent;
                const image = card.querySelector('img').src;

                document.getElementById('modalTitle').textContent = "Editează Donație";
                createModal.style.display = 'flex';
                document.getElementById('title').value = titlu;
                document.getElementById('description').value = descriere;
                document.getElementById('image').value = image;
                document.getElementById('amount').value = parseFloat(sumaSpan.textContent);
                document.getElementById('donation_id').value = card.dataset.id;
            });

            deleteBtn.addEventListener('click', () => {
                if(confirm("Sigur vrei să ștergi această donație?")){
                    fetch('donation.php', {
                        method: 'POST',
                        body: new URLSearchParams({donation_id: card.dataset.id, delete: 1})
                    }).then(()=> card.remove());
                }
            });
        }
    }

    document.querySelectorAll('.card').forEach(card => attachCardEvents(card));

    const createDonationForm = document.getElementById('createDonationForm');
    if(createDonationForm){
        createDonationForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const id = document.getElementById('donation_id').value;
            const titlu = document.getElementById('title').value;
            const descriere = document.getElementById('description').value;
            const image = document.getElementById('image').value;
            const suma = parseFloat(document.getElementById('amount').value) || 0;

            const formData = new URLSearchParams();
            formData.append('donation_id', id);
            formData.append('titlu', titlu);
            formData.append('descriere', descriere);
            formData.append('image_path', image);
            formData.append('suma', suma);

            if(id === '') formData.append('new', 1);

            fetch('donation.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.success){
                    if(id){
                        const oldCard = document.querySelector(`.card[data-id='${id}']`);
                        if(oldCard) oldCard.remove();
                    }

                    const card = document.createElement('div');
                    card.classList.add('card');
                    card.dataset.id = data.id;
                    card.innerHTML = `
                        <img src="${image}" alt="${titlu}">
                        <div class="titlu"><p>${titlu}</p></div>
                        <p>${descriere}</p>
                        <p>Suma: <span class="suma">${suma.toFixed(2)}</span> RON</p>
                        <button class="donateBtn">Donează</button>
                        ${userRole === 'admin' ? '<button class="editBtn">Editează</button><button class="deleteBtn">Șterge</button>' : ''}
                    `;
                    listaDonatii.prepend(card);
                    attachCardEvents(card);

                    createModal.style.display = 'none';
                    createDonationForm.reset();
                } else {
                    alert("Eroare: " + data.message);
                }
            })
            .catch(err => {
                console.error(err);
                alert("A apărut o eroare.");
            });
        });
    }

    window.onclick = function(event){
        if(event.target === loginModal) loginModal.style.display = 'none';
        if(event.target === createModal) createModal.style.display = 'none';
    }

    const backToTop = document.querySelector('.back-to-top');
    window.addEventListener('scroll', () => {
        if(!backToTop) return;
        backToTop.style.display = window.scrollY > 300 ? 'block' : 'none';
    });
});
