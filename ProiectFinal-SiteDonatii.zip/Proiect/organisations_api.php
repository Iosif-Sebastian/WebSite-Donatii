<?php
session_start();
require 'db.php';

$action = $_GET['action'] ?? '';
$userRole = $_SESSION['userRole'] ?? '';

if($action === 'get'){
    $stmt = $pdo->query("SELECT * FROM organisations ORDER BY id DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if(!$userRole){
    echo json_encode(['success'=>false,'message'=>'Neautorizat']);
    exit;
}

if(isset($_POST['nume'])){
    $id = $_POST['org_id'] ?? '';
    $nume = $_POST['nume'];
    $descriere = $_POST['descriere'];
    $email = $_POST['contact_email'];
    $telefon = $_POST['contact_telefon'];
    $image = $_POST['image_path'];

    if($id){ 
        if($userRole !== 'admin'){
            echo json_encode(['success'=>false,'message'=>'Doar admin poate modifica']);
            exit;
        }
        $stmt = $pdo->prepare("UPDATE organisations SET nume=?, descriere=?, contact_email=?, contact_telefon=?, image_path=? WHERE id=?");
        $stmt->execute([$nume,$descriere,$email,$telefon,$image,$id]);
    } else { 
        $stmt = $pdo->prepare("INSERT INTO organisations (nume,descriere,contact_email,contact_telefon,image_path) VALUES (?,?,?,?,?)");
        $stmt->execute([$nume,$descriere,$email,$telefon,$image]);
    }

    echo json_encode(['success'=>true]);
    exit;
}


if(isset($_POST['delete'])){
    if($userRole !== 'admin'){
        echo json_encode(['success'=>false,'message'=>'Doar admin poate șterge']);
        exit;
    }
    $id = $_POST['id'];
    $stmt = $pdo->prepare("DELETE FROM organisations WHERE id=?");
    $stmt->execute([$id]);
    echo json_encode(['success'=>true]);
    exit;
}
