<?php
session_start();
require 'db.php'; // $pdo aici
$userRole = $_SESSION['userRole'] ?? '';
$userName = $_SESSION['userName'] ?? '';
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evenimente | SearchForACause</title>
    <link rel="stylesheet" href="style_events.css">
</head>
<body id="top">

<header class="main-header">
    <div class="logo">SearchForACause</div>
    <nav class="nav-links">
        <a href="Home.php">Acasă</a>
        <a href="About.html">Despre</a>
        <a href="Organisations.php">Organizații</a>
        <a href="Contact.php">Contact</a>
        <?php if(!$userRole): ?>
            <button class="login-btn" id="loginBtn">Autentifică-te</button>
        <?php else: ?>
            <span style="color:white;">Bine ai venit, <?= htmlspecialchars($userName) ?></span>
           <button id="logoutBtn">Ieși</button>
            <button id="openCreateBtn">Creează Eveniment</button>
        <?php endif; ?>
    </nav>
</header>

<div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeLogin">&times;</span>
        <h2>Conectează-te</h2>
        <div id="loginChoice">
            <button id="userLoginBtn">User</button>
            <button id="adminLoginBtn">Admin</button>
            <button id="createUserBtn">Creează cont</button>
        </div>
        <form id="loginForm" method="POST" action="login.php" style="display:none;">
            <input type="hidden" name="role" id="loginRole" value="">
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Parola:</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>
        <p id="createUserLink" style="display:none;">Nu ai cont? <a href="CreareCont.html">Creează unul</a></p>
    </div>
</div>

<div id="createModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeCreate">&times;</span>
        <h2 id="eventModalTitle">Creează Eveniment</h2>
        <form id="createEventForm">
            <input type="hidden" name="event_id" id="event_id" value="">
            <input type="text" id="event_title" name="titlu" placeholder="Titlu" required>
            <textarea id="event_description" name="descriere" placeholder="Descriere" required></textarea>
            <input type="text" id="event_location" name="locatie" placeholder="Locație" required>
            <input type="datetime-local" id="event_date" name="data_eveniment" required>
            <input type="text" id="event_image" name="image_path" placeholder="URL imagine">
            <button type="submit">Trimite Eveniment</button>
        </form>
    </div>
</div>

<main class="events-container">
    <div class="page-title"><p>Evenimente</p></div>
    <p class="subtitle">Caută evenimentele care te interesează și implică-te în comunitate</p>
    <form class="searchbar" id="searchForm">
        <input type="text" placeholder="Caută un eveniment..." id="searchInput">
        <button type="button">Caută</button>
    </form>
    <div class="card-container" id="eventsContainer"></div>
</main>

<a href="#top" class="back-to-top">⬆ Mergi sus</a>
<footer>
    <p>© 2025 Search For a Cause — Toate drepturile rezervate</p>
</footer>

<script>
window.userRole = "<?= $userRole ?>";
</script>
<script src="script_events.js"></script>
</body>
</html>
