CREATE TABLE donatii (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(255),
    descriere VARCHAR(255),
    suma INT
);