<?php
session_start();
$userRole = $_SESSION['userRole'] ?? '';
$userName = $_SESSION['userName'] ?? '';
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Organizații | SearchForACause</title>
    <link rel="stylesheet" href="style_organisations.css">
</head>
<body id="top">

<header class="main-header">
    <div class="logo">SearchForACause</div>
    <nav class="nav-links">
        <a href="Home.php">Acasă</a>
        <a href="About.html">Despre</a>
        <a href="events.php">Evenimente</a>
        <a href="Contact.php">Contact</a>

        <?php if(!$userRole): ?>
            <button class="login-btn" id="loginBtn">Autentifică-te</button>
        <?php else: ?>
            <span class="welcome">Bine ai venit, <?= htmlspecialchars($userName) ?></span>
            <button id="logoutBtn">Ieși</button>
            <?php if($userRole === 'user' || $userRole === 'admin'): ?>
                <button id="openCreateBtn">Creează Organizație</button>
            <?php endif; ?>
        <?php endif; ?>
    </nav>
</header>

<div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeLogin">&times;</span>
        <h2>Conectează-te</h2>
        <div id="loginChoice">
            <button id="userLoginBtn">User</button>
            <button id="adminLoginBtn">Admin</button>
            <button id="createUserBtn"><a href="CreareCont.html">Creează cont</a></button>
        </div>
        <form id="loginForm" method="POST" action="login.php" style="display:none;">
            <input type="hidden" name="role" id="loginRole">
            <label>Email</label>
            <input type="email" name="email" required>
            <label>Parola</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</div>


<div id="createModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeCreate">&times;</span>
        <h2 id="modalTitle">Creează Organizație</h2>
        <form id="createOrgForm">
            <input type="hidden" id="org_id">
            <input type="text" id="nume" placeholder="Nume organizație" required>
            <textarea id="descriere" placeholder="Descriere" required></textarea>
            <input type="email" id="contact_email" placeholder="Email" required>
            <input type="text" id="contact_telefon" placeholder="Telefon">
            <input type="text" id="image_path" placeholder="URL imagine" required>
            <button type="submit">Salvează</button>
        </form>
    </div>
</div>

<main class="organisations-container">
    <div class="page-title">
        <h1>Organizații partenere</h1>
        <p>Descoperă organizațiile care fac diferența</p>
    </div>

    <div class="card-container" id="orgContainer"></div>
</main>

<a href="#top" class="back-to-top">↑</a>

<footer>
    <p>© 2025 Search For a Cause — Toate drepturile rezervate</p>
</footer>

<script>
    window.userRole = "<?= $userRole ?>";
</script>
<script src="script_organisations.js"></script>
</body>
</html>
