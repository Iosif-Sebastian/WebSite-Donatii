<?php
session_start();
require 'db.php'; 
header('Content-Type: application/json');

if(!isset($_SESSION['userRole'])){
    echo json_encode(['success'=>false,'message'=>'Nu ești autentificat']);
    exit;
}

if(isset($_POST['delete'], $_POST['donation_id'])){
    if($_SESSION['userRole'] !== 'admin'){
        echo json_encode(['success'=>false,'message'=>'Nu ai permisiune']);
        exit;
    }
    $stmt = $pdo->prepare("DELETE FROM donatii WHERE id=?");
    $stmt->execute([$_POST['donation_id']]);
    echo json_encode(['success'=>true]);
    exit;
}

if(isset($_POST['donation_id'], $_POST['suma']) && !isset($_POST['titlu'])){
    $stmt = $pdo->prepare("UPDATE donatii SET suma=? WHERE id=?");
    $stmt->execute([floatval($_POST['suma']), $_POST['donation_id']]);
    echo json_encode(['success'=>true]);
    exit;
}

$titlu = $_POST['titlu'] ?? '';
$descriere = $_POST['descriere'] ?? '';
$image_path = $_POST['image_path'] ?? '';
$suma = floatval($_POST['suma'] ?? 0);
$id = $_POST['donation_id'] ?? '';

try {
    if($id){ 
        if($_SESSION['userRole'] !== 'admin') {
            echo json_encode(['success'=>false, 'message'=>'Nu ai permisiune']);
            exit;
        }
        $stmt = $pdo->prepare("UPDATE donatii SET titlu=?, descriere=?, image_path=?, suma=? WHERE id=?");
        $stmt->execute([$titlu, $descriere, $image_path, $suma, $id]);
        echo json_encode(['success'=>true, 'id'=>$id]);
    } else { 
        $stmt = $pdo->prepare("INSERT INTO donatii (titlu, descriere, image_path, suma) VALUES (?,?,?,?)");
        $stmt->execute([$titlu, $descriere, $image_path, $suma]);
        echo json_encode(['success'=>true, 'id'=>$pdo->lastInsertId()]);
    }
} catch(PDOException $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
