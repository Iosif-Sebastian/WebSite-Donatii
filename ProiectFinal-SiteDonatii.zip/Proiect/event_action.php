<?php
session_start();
require 'db.php';
header('Content-Type: application/json');

$userRole = $_SESSION['userRole'] ?? '';


if(isset($_GET['action']) && $_GET['action']==='get'){
    $stmt=$pdo->query("SELECT * FROM events ORDER BY data_crearii DESC");
    $events=$stmt->fetchAll();
    echo json_encode($events);
    exit;
}

if(!$userRole){ echo json_encode(['success'=>false,'message'=>'Nu ești autentificat']); exit; }


if(isset($_POST['delete'], $_POST['event_id'])){
    if($userRole!=='admin'){ echo json_encode(['success'=>false,'message'=>'Nu ai permisiune']); exit; }
    $stmt=$pdo->prepare("DELETE FROM events WHERE id=?");
    $stmt->execute([$_POST['event_id']]);
    echo json_encode(['success'=>true]); exit;
}
$titlu = $_POST['titlu'] ?? '';
$descriere = $_POST['descriere'] ?? '';
$locatie = $_POST['locatie'] ?? '';
$data_eveniment = $_POST['data_eveniment'] ?? '';
$image_path = $_POST['image_path'] ?? '';
$id = $_POST['event_id'] ?? '';

try{
    if($id){ 
        if($userRole!=='admin'){ echo json_encode(['success'=>false,'message'=>'Nu ai permisiune']); exit; }
        $stmt=$pdo->prepare("UPDATE events SET titlu=?, descriere=?, locatie=?, data_eveniment=?, image_path=? WHERE id=?");
        $stmt->execute([$titlu,$descriere,$locatie,$data_eveniment,$image_path,$id]);
        echo json_encode(['success'=>true,'id'=>$id]);
    } else {
        $stmt=$pdo->prepare("INSERT INTO events(titlu,descriere,locatie,data_eveniment,image_path) VALUES(?,?,?,?,?)");
        $stmt->execute([$titlu,$descriere,$locatie,$data_eveniment,$image_path]);
        echo json_encode(['success'=>true,'id'=>$pdo->lastInsertId()]);
    }
}catch(PDOException $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
