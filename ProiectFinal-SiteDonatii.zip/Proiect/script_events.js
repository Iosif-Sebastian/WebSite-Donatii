document.addEventListener('DOMContentLoaded', () => {
    const userRole = window.userRole || "";

    const loginModal = document.getElementById('loginModal');
    const createModal = document.getElementById('createModal');
    const eventsContainer = document.getElementById('eventsContainer');

    const loginBtn = document.getElementById('loginBtn');
    const openCreateBtn = document.getElementById('openCreateBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    const closeLoginBtn = document.getElementById('closeLogin');
    const closeCreateBtn = document.getElementById('closeCreate');

    const loginRoleInput = document.getElementById('loginRole');
    const loginChoice = document.getElementById('loginChoice');
    const loginForm = document.getElementById('loginForm');
    const createUserLink = document.getElementById('createUserLink');

  

    if (loginBtn) {
        loginBtn.addEventListener('click', () => {
            loginModal.style.display = 'flex';
        });
    }

    if (closeLoginBtn) {
        closeLoginBtn.addEventListener('click', () => {
            loginModal.style.display = 'none';
        });
    }

    if (closeCreateBtn) {
        closeCreateBtn.addEventListener('click', () => {
            createModal.style.display = 'none';
        });
    }

    const userLoginBtn = document.getElementById('userLoginBtn');
    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const createUserBtn = document.getElementById('createUserBtn');

    if (userLoginBtn) userLoginBtn.addEventListener('click', () => switchLogin('user'));
    if (adminLoginBtn) adminLoginBtn.addEventListener('click', () => switchLogin('admin'));
    if (createUserBtn) createUserBtn.addEventListener('click', () => switchLogin('create'));

    function switchLogin(role) {
        loginRoleInput.value = role;
        loginChoice.style.display = 'none';

        if (role === 'create') {
            loginForm.style.display = 'none';
            createUserLink.style.display = 'block';
        } else {
            loginForm.style.display = 'block';
            createUserLink.style.display = 'none';
        }
    }


    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            fetch('logout.php', { method: 'POST' })
                .then(() => {
                    location.reload(); 
                });
        });
    }

    if (openCreateBtn) {
        openCreateBtn.addEventListener('click', () => {
            if (!userRole) {
                alert("Trebuie să te autentifici!");
                return;
            }

            createModal.style.display = 'flex';
            document.getElementById('createEventForm').reset();
            document.getElementById('event_id').value = '';
            document.getElementById('eventModalTitle').textContent = "Creează Eveniment";
        });
    }


    function loadEvents() {
        fetch('event_action.php?action=get')
            .then(res => res.json())
            .then(data => {
                eventsContainer.innerHTML = '';

                data.forEach(event => {
                    const card = document.createElement('div');
                    card.classList.add('card');
                    card.dataset.id = event.id;

                    card.innerHTML = `
                        <img src="${event.image_path}" alt="${event.titlu}">
                        <div class="titlu"><p>${event.titlu}</p></div>
                        <p>${event.descriere}</p>
                        <p>Locație: ${event.locatie}</p>
                        <p>Data: ${event.data_eveniment}</p>
                        ${userRole === 'admin' ? `
                            <button class="editBtn">Editează</button>
                            <button class="deleteBtn">Șterge</button>
                        ` : ''}
                    `;

                    eventsContainer.appendChild(card);
                    attachCardEvents(card);
                });
            });
    }

    function attachCardEvents(card) {
        if (userRole !== 'admin') return;

        const editBtn = card.querySelector('.editBtn');
        const deleteBtn = card.querySelector('.deleteBtn');

        if (editBtn) {
            editBtn.addEventListener('click', () => {
                const titlu = card.querySelector('.titlu p').textContent;
                const descriere = card.querySelector('p:nth-of-type(1)').textContent;
                const locatie = card.querySelector('p:nth-of-type(2)').textContent.replace('Locație: ', '');
                const data_eveniment = card.querySelector('p:nth-of-type(3)').textContent.replace('Data: ', '');

                document.getElementById('eventModalTitle').textContent = "Editează Eveniment";
                createModal.style.display = 'flex';

                document.getElementById('event_title').value = titlu;
                document.getElementById('event_description').value = descriere;
                document.getElementById('event_location').value = locatie;
                document.getElementById('event_date').value = data_eveniment;
                document.getElementById('event_id').value = card.dataset.id;
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                if (!confirm("Sigur vrei să ștergi acest eveniment?")) return;

                fetch('event_action.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        event_id: card.dataset.id,
                        delete: 1
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        card.remove();
                    } else {
                        alert("Eroare la ștergere");
                    }
                });
            });
        }
    }


    const createEventForm = document.getElementById('createEventForm');

    if (createEventForm) {
        createEventForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const formData = new URLSearchParams();
            formData.append('event_id', document.getElementById('event_id').value);
            formData.append('titlu', document.getElementById('event_title').value);
            formData.append('descriere', document.getElementById('event_description').value);
            formData.append('locatie', document.getElementById('event_location').value);
            formData.append('data_eveniment', document.getElementById('event_date').value);
            formData.append('image_path', document.getElementById('event_image').value);

            fetch('event_action.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    createModal.style.display = 'none';
                    createEventForm.reset();
                    loadEvents();
                } else {
                    alert("Eroare: " + data.message);
                }
            });
        });
    }


    const backToTop = document.querySelector('.back-to-top');

    if (backToTop) {
        window.addEventListener('scroll', () => {
            backToTop.style.display = window.scrollY > 300 ? 'block' : 'none';
        });
    }


    loadEvents();
});
