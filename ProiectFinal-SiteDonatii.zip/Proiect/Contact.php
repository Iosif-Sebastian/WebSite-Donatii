<?php
session_start();
require 'db.php'; 

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nume = trim($_POST['nume']);
    $prenume = trim($_POST['prenume']);
    $email = trim($_POST['email']);
    $subiect = trim($_POST['subiect']);
    $mesaj = trim($_POST['mesaj']);

    if ($nume && $prenume && $email && $subiect && $mesaj) {
        try {
            $stmt = $pdo->prepare("INSERT INTO contact (nume, prenume, email, subiect, mesaj) VALUES (:nume, :prenume, :email, :subiect, :mesaj)");
            $stmt->execute([
                ':nume' => $nume,
                ':prenume' => $prenume,
                ':email' => $email,
                ':subiect' => $subiect,
                ':mesaj' => $mesaj
            ]);
            $success = "Mesajul tău a fost trimis cu succes!";
        } catch (PDOException $e) {
            $error = "A apărut o eroare: " . $e->getMessage();
        }
    } else {
        $error = "Toate câmpurile sunt obligatorii!";
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact | SearchForACause</title>
<link rel="stylesheet" href="style_contact.css">
</head>
<body id="top">

<header class="main-header">
    <div class="logo">SearchForACause</div>
    <nav class="nav-links">
      <a href="Home.php">Acasă</a>
      <a href="About.html">Despre</a>
      <a href="Organisations.php">Organizații</a>
      <a href="Events.php">Evenimente</a>

      <?php if(isset($_SESSION['user_id'])): ?>
        <span style="color:white;">Salut, <?= htmlspecialchars($_SESSION['username']); ?></span>
        <form style="display:inline;" action="logout.php" method="post">
            <button type="submit" class="logout-btn">Ieși</button>
        </form>
        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <a href="admin_modifica.php" class="admin-btn">Modifică</a>
        <?php endif; ?>
      <?php else: ?>
        <button class="login-btn" onclick="openLogin()">Autentifică-te</button>
      <?php endif; ?>
    </nav>
</header>

<div id="loginModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeLogin()">&times;</span>
      <h2>Conectează-te</h2>
      <form method="post" action="login.php">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        <label for="password">Parola</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Conectează-te</button>
      </form>
      <p>Nu ai cont? <a href="CreareCont.html">Creează unul acum</a></p>
    </div>
</div>

<main class="contact-container">
    <h1>Contactează-ne</h1>

    <?php if($success) echo "<p class='success-msg'>$success</p>"; ?>
    <?php if($error) echo "<p class='error-msg'>$error</p>"; ?>

    <section class="contact-form-section">
      <form class="contact-form" action="contact.php" method="post">
        <div class="input-group">
          <label for="nume">Nume</label>
          <input type="text" id="nume" name="nume" placeholder="Numele tău" required>
        </div>

        <div class="input-group">
          <label for="prenume">Prenume</label>
          <input type="text" id="prenume" name="prenume" placeholder="Prenumele tău" required>
        </div>

        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="example@gmail.com" required>
        </div>

        <div class="input-group">
          <label for="mesaj">Mesaj</label>
          <textarea id="mesaj" name="mesaj" rows="5" placeholder="Scrie mesajul tău..." required></textarea>
        </div>

        <div class="radio-group">
          <p>Alege subiectul întrebării tale:</p>
          <label><input type="radio" name="subiect" value="general" checked> Întrebare generală</label>
          <label><input type="radio" name="subiect" value="tehnic"> Probleme tehnice</label>
        </div>

        <button type="submit" class="submit-btn">Trimite mesajul</button>
      </form>

      <aside class="contact-info">
        <h2>Informații utile</h2>
        <p><strong>Email:</strong> contact@searchforacause.ro</p>
        <p><strong>Telefon:</strong> +40 123 456 789</p>
        <p><strong>Program:</strong> Luni-Vineri, 9:00-17:00</p>
      </aside>
    </section>

    <a href="#top" class="back-to-top">⬆️ Mergi sus</a>
</main>

<footer>
    <p>© 2025 Search For a Cause — Toate drepturile rezervate</p>
</footer>

<script src="script_contact.js"></script>
</body>
</html>
