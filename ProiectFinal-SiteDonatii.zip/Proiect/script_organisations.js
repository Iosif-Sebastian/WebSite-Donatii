document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const loginModal = document.getElementById('loginModal');
    const closeLogin = document.getElementById('closeLogin');
    const userLoginBtn = document.getElementById('userLoginBtn');
    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const loginForm = document.getElementById('loginForm');
    const loginChoice = document.getElementById('loginChoice');
    const loginRoleInput = document.getElementById('loginRole');

    const openCreateBtn = document.getElementById('openCreateBtn');
    const createModal = document.getElementById('createModal');
    const closeCreate = document.getElementById('closeCreate');
    const createOrgForm = document.getElementById('createOrgForm');
    const modalTitle = document.getElementById('modalTitle');

    if (loginBtn) loginBtn.addEventListener('click', () => loginModal.style.display = 'flex');
    if (closeLogin) closeLogin.addEventListener('click', () => {
        loginModal.style.display = 'none';
        resetLoginModal();
    });

    if (userLoginBtn) userLoginBtn.addEventListener('click', () => {
        loginChoice.style.display = 'none';
        loginForm.style.display = 'block';
        loginRoleInput.value = 'user';
    });
    if (adminLoginBtn) adminLoginBtn.addEventListener('click', () => {
        loginChoice.style.display = 'none';
        loginForm.style.display = 'block';
        loginRoleInput.value = 'admin';
    });

    function resetLoginModal() {
        loginChoice.style.display = 'block';
        loginForm.style.display = 'none';
    }

    if (logoutBtn) logoutBtn.addEventListener('click', () => {
        fetch('logout.php', { method: 'POST' })
            .then(() => location.reload());
    });

    loadOrganisations();

    function loadOrganisations() {
        fetch('organisations_api.php?action=get')
            .then(res => res.json())
            .then(data => {
                const container = document.getElementById('orgContainer');
                container.innerHTML = '';

                data.forEach(org => {
                    const div = document.createElement('div');
                    div.className = 'card';

                    div.innerHTML = `
                        <img src="${org.image_path}" alt="${org.nume}">
                        <div class="titlu1"><p>${org.nume}</p></div>
                        <p>${org.descriere}</p>
                        <p><b>Email:</b> ${org.contact_email}</p>
                        <p><b>Telefon:</b> ${org.contact_telefon || '-'}</p>
                    `;

                    if (window.userRole === 'user' || window.userRole === 'admin') {
                        const editBtn = document.createElement('button');
                        editBtn.textContent = 'Modifică';
                        editBtn.className = 'editBtn';
                        editBtn.addEventListener('click', () => openEditModal(org));
                        div.appendChild(editBtn);
                    }

                    if (window.userRole === 'admin') {
                        const deleteBtn = document.createElement('button');
                        deleteBtn.textContent = 'Șterge';
                        deleteBtn.className = 'deleteBtn';
                        deleteBtn.addEventListener('click', () => deleteOrg(org.id));
                        div.appendChild(deleteBtn);
                    }

                    container.appendChild(div);
                });
            });
    }

    if (openCreateBtn) {
        openCreateBtn.addEventListener('click', () => {
            modalTitle.textContent = 'Creează Organizație';
            createOrgForm.reset();
            createModal.style.display = 'flex';
            createOrgForm.dataset.editing = '';
        });
    }

    if (closeCreate) {
        closeCreate.addEventListener('click', () => createModal.style.display = 'none');
    }

    createOrgForm.addEventListener('submit', e => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('nume', document.getElementById('nume').value);
        formData.append('descriere', document.getElementById('descriere').value);
        formData.append('contact_email', document.getElementById('contact_email').value);
        formData.append('contact_telefon', document.getElementById('contact_telefon').value);
        formData.append('image_path', document.getElementById('image_path').value);

        const editingId = createOrgForm.dataset.editing;
        if (editingId) formData.append('id', editingId);

        fetch('organisations_api.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(editingId ? 'Organizație modificată!' : 'Organizație creată!');
                createModal.style.display = 'none';
                createOrgForm.reset();
                loadOrganisations();
            } else {
                alert(data.message);
            }
        });
    });

    function openEditModal(org) {
        modalTitle.textContent = 'Modifică Organizație';
        createModal.style.display = 'flex';
        createOrgForm.dataset.editing = org.id;

        document.getElementById('nume').value = org.nume;
        document.getElementById('descriere').value = org.descriere;
        document.getElementById('contact_email').value = org.contact_email;
        document.getElementById('contact_telefon').value = org.contact_telefon;
        document.getElementById('image_path').value = org.image_path;
    }

    function deleteOrg(id) {
        if (!confirm('Sigur vrei să ștergi organizația?')) return;

        const formData = new FormData();
        formData.append('delete', '1');
        formData.append('id', id);

        fetch('organisations_api.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert('Șters cu succes!');
                loadOrganisations();
            } else {
                alert(data.message);
            }
        });
    }

    const backToTop = document.querySelector('.back-to-top');
    window.addEventListener('scroll', () => {
        backToTop.style.display = window.scrollY > 300 ? 'block' : 'none';
    });
});
