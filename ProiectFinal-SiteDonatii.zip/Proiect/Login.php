<?php
session_start();
require 'db.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';
$redirect = $_POST['redirect_to'] ?? $_SERVER['HTTP_REFERER'] ?? 'Home.php';

if (empty($email) || empty($password) || empty($role)) {
    die("Date incomplete!");
}

try {
    if ($role === 'user') {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    } elseif ($role === 'admin') {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    } else {
        die("Rol invalid!");
    }

    $stmt->execute([$email]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$account) {
        die("Utilizator inexistent!");
    }

    if ($password === $account['password']) {

        $_SESSION['userRole'] = $role;
        $_SESSION['userEmail'] = $account['email'];

        if ($role === 'user') {
            $_SESSION['userName'] = $account['name'];
        } else {
            $_SESSION['userName'] = $account['username'];
        }

        header("Location: " . $redirect);
        exit;

    } else {
        die("Parolă incorectă!");
    }

} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}
