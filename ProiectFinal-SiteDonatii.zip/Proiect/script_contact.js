const loginModal = document.getElementById('loginModal');
const loginBtn = document.querySelector('.login-btn');
const closeBtn = document.querySelector('.close');

function openLogin() {
  loginModal.style.display = 'flex';
}
function closeLogin() {
  loginModal.style.display = 'none';
}

window.onclick = function(event) {
  if (event.target === loginModal) {
    closeLogin();
  }
}

const backToTopBtn = document.querySelector('.back-to-top');

window.onscroll = function() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    backToTopBtn.style.display = 'block';
  } else {
    backToTopBtn.style.display = 'none';
  }
};

backToTopBtn.addEventListener('click', function(e) {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
