<?php
header('Content-Type: application/json');
require 'db.php';  

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {

    $stmt = $pdo->query("SELECT * FROM studenti ORDER BY id DESC");
    $studenti = $stmt->fetchAll();
    echo json_encode($studenti);

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $nume = trim($data['nume'] ?? '');
    $anul = (int)($data['anul'] ?? 0);
    $media = (float)($data['media'] ?? -1);

    if (!$nume || $anul < 1 || $anul > 4 || $media < 0 || $media > 10) {
        http_response_code(400);
        echo json_encode(["error" => "Date invalide"]);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO studenti (nume, anul, media) VALUES (:nume, :anul, :media)");
    $stmt->execute(['nume' => $nume, 'anul' => $anul, 'media' => $media]);

    echo json_encode(["success" => true]);
}
?>
